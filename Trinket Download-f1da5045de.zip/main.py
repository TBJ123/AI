#Pacman Ghost Algorithm - www.101computing.net/pacman-ghost-algorithm/
from math import atan, cos, sin
from processing import *

img = loadImage('rocketship.gif')
WIDTH=500
HEIGHT=500
pacman_X = 50
pacman_Y = 50
delay = 5

ghost_X1 = 10
ghost_Y1 = 10
ghost_X2 = 70
ghost_Y2 = 70

def setup():
    strokeWeight(3)
    frameRate(20)
    size(WIDTH,HEIGHT)

def moveGhost1():    
  global ghost_X1,ghost_Y1,pacman_X,pacman_Y
  fill(125,110,0)
  stroke(255,255,255)
  
  #Find out the direction (angle) the Ghost needs to move towards
  #Using SOH-CAH-TOA trignometic rations
  opposite=pacman_Y-ghost_Y1
  adjacent=pacman_X-ghost_X1
  angle = atan(opposite/adjacent)
  if ghost_X1>pacman_X:
    angle=angle+180
  
  #Use this angle to calculate the velocity vector of the Ghost
  #Once again using SOH-CAH-TOA trignometic rations
  velocity=5 #pixels per frame
  
  vx = velocity * cos(angle)
  vy = velocity * sin(angle)
  
  #Apply velocity vector to the Ghost coordinates to move/translate the ghost
  ghost_X1 = ghost_X1 + vx
  ghost_Y1 = ghost_Y1 + vy
  
  #Draw Ghost  
  ellipse( ghost_X1,ghost_Y1,40,50)
  
def moveGhost2():    
  global ghost_X2,ghost_Y2,pacman_X,pacman_Y
  fill(125,110,0)
  stroke(255,255,255)
  
  #Find out the direction (angle) the Ghost needs to move towards
  #Using SOH-CAH-TOA trignometic rations
  opposite=pacman_Y-ghost_Y2
  adjacent=pacman_X-ghost_X2
  angle = atan(opposite/adjacent)
  if ghost_X2>pacman_X:
    angle=angle+180
  
  #Use this angle to calculate the velocity vector of the Ghost
  #Once again using SOH-CAH-TOA trignometic rations
  velocity=7 #pixels per frame
  
  vx = velocity * cos(angle)
  vy = velocity * sin(angle)
  
  #Apply velocity vector to the Ghost coordinates to move/translate the ghost
  ghost_X2 = ghost_X2 + vx
  ghost_Y2 = ghost_Y2 + vy
  
  #Draw Ghost  
  ellipse( ghost_X2,ghost_Y2,20,20)
    
def movePacman():
    global pacman_X, pacman_Y

    fill(255,255,0)
    stroke(0,0,0)
    fc = environment.frameCount

    #Pacman follows the mouse cursor
    pacman_X += (mouse.x-pacman_X)/delay;
    pacman_Y += (mouse.y-pacman_Y)/delay;
    
    #Draw Pacman
    #ellipse(pacman_X,pacman_Y,20,20)
    image(img,pacman_X,pacman_Y)
def playGame():
  background(30,50,100)
  movePacman()
  moveGhost1()
  moveGhost2()

draw = playGame
run()
